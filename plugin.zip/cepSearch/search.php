<script src="https://code.jquery.com/jquery-3.6.0.js"></script>

<script>
    $(document).on('click','#search', function() {
        var cep = $("#cep").val();
        $.ajax({
            type: "get",
            url: "https://viacep.com.br/ws/"+cep+"/json/",
            success: function(data){
                var conteudo = '';
                conteudo += "<p>Estado: "+data.uf+"</p>";
                conteudo += "<p>Cidade: "+data.localidade+"</p>";
                conteudo += "<p>Bairro: "+data.bairro+"</p>";
                conteudo += "<p>Logradouro: "+data.logradouro+"</p>";

                $("#result").append(conteudo);
            }
        });
    });
</script>

<div class="cContent">
    <div class="centerContent">
        <input type="text" id="cep" placeholder="CEP Search" title="CEP Search">

        <button id="search">Search</button>
        
        <div id="result"></div>
    </div>
</div>
<style type="text/css">
    :root {
        --darkgreen: #3cb371;
        --lightgreen: #55CE8B;
        --grey: #757776;
        --white: #ffffff;
        --border: 5px solid var(--darkgreen);
        --padding: 5px 10px;
    }
    
    .centerContent {
        flex-direction: column;
        gap: 5px;
    }
    
    .cContent,
    .centerContent {
        display: flex;
        justify-content: center;
    }
    
    #cep {
        text-align: center;
    }
    
    #cep,
    #search,
    #result {
        border: var(--border);
        padding: var(--padding);
        outline: none;
        font-weight: 600;
        font-family: Arial, sans-serif;
        background: var(--lightgreen);
        color: var(--grey);
    }
    
    #search,
    #search:hover,
    #search:active,
    #result,
    #result:hover {
        transition: ease-in-out 350ms;
    }
    
    #search:hover,
    #result:hover {
        background: var(--darkgreen);
        color: var(--white);
    }
    
    #search:active {
        background: var(--lightgreen);
        color: var(--grey);
    }
</style>