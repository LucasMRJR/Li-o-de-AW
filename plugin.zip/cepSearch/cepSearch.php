<?php

/*
 * Plugin name: CEP Search
 * Description: A CEP search plugin
 * Version: 1.5
*/ 

function cepsrh() {
    echo file_get_contents(plugins_url().'/cepSearch/search.php');
}

add_shortcode('CEPS', 'cepsrh');

?>